package csc472.depaul.edu.micvalmoy.quizizz;

//import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
///------------------------------


import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

import csc472.depaul.edu.micvalmoy.entity.Category;
import csc472.depaul.edu.micvalmoy.entity.Question;
import csc472.depaul.edu.micvalmoy.entity.QuestionAnswerOption;
import csc472.depaul.edu.micvalmoy.entity.Quiz;
import csc472.depaul.edu.micvalmoy.quizizz.jsonObj.Option;
import csc472.depaul.edu.micvalmoy.quizizz.jsonObj.QuizInfo;
import csc472.depaul.edu.micvalmoy.quizizz.jsonObj.QuizizzQuestion;
import csc472.depaul.edu.micvalmoy.tools.Converters;
import csc472.depaul.edu.micvalmoy.tools.HttpHandler;
import csc472.depaul.edu.micvalmoy.quizizz.jsonObj.Quizizz;
import csc472.depaul.edu.micvalmoy.quizizz.jsonObj.Structure;
import timber.log.Timber;

/**
 * https://quizizz.com/api/main/search?query=php
 * https://quizizz.com/quiz/5762b0f0e75c06a70b08c172
 */

public class QuizizzJson {

    private String TAG = QuizizzJson.class.getSimpleName();
    String searchTermUrl = "https://quizizz.com/api/kilim1/search?from=0&sortKey=_score&filterList={%22grade_type.aggs%22%3A[]%2C%22occupation%22%3A[%22teacher_school%22%2C%22teacher_university%22%2C%22other%22%2C%22teacher%22]%2C%22cloned%22%3A[false]%2C%22subjects.aggs%22%3A[]}&queryId=5bc37369f2292f001b141f31-1539574984208&source=MainHeader&page=QuizPage&query=";

    String searchIdUrl ="https://quizizz.com/quiz/";


    public Quizizz parseQuizizzJson(String jsonStr) {

        // DATA as root
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.registerTypeAdapter(Structure.class, new JsonStructureDeserializer())
                .excludeFieldsWithoutExposeAnnotation().create();

        Gson gson = gsonBuilder.create();
        Quizizz quizizz = gson.fromJson(jsonStr, Quizizz.class);
        Timber.d("---------------------------------------------------------------------------------------------");
        Timber.d("Quizziz GSON parsed | Quizizz object Created :\t\t %s" , quizizz.toString());
        Timber.d("---------------------------------------------------------------------------------------------");

        return quizizz;
    }
    public Quizizz getJsonResponseBySearchTerm(String searchParameter) {
        return getJsonResponse (searchParameter,searchTermUrl);
    }
    public Quizizz getJsonResponseById(String searchParameter) {
        return getJsonResponse (searchParameter,searchIdUrl);
    }


    public Quizizz getJsonResponse (String searchParameter, String websiteUrl) {
        Quizizz qz = null;

        String url =  websiteUrl + searchParameter;

        //The Url of the json content, the search parameter is a part of the url


        HttpHandler sh = new HttpHandler();

        //** connect to the quizizz website, and download the json content
        String jsonStr = sh.makeServiceCall(url);


        Timber.d("---------------------------------------------------------------------------------------------");
        Timber.d("Response from url: %s", url);
        Timber.d("Response jsonStr :\t\t %s", jsonStr);
        Timber.d("---------------------------------------------------------------------------------------------");
        if (jsonStr != null) {
            try {
                qz = parseQuizizzJson(jsonStr);
            } catch (Exception e) {
                Timber.e(e,"Json parsing error %s",url);
            }
        } else {
            Timber.d("Couldn't get json from server%s",url);
        }
        return qz;
    }






    public Quiz  buildQuizToImport(QuizInfo quizInfo) {
        Quiz quiz = new Quiz();

        String quest_name = quizInfo.getName();
        quiz.setName(quest_name);

        //-------------------------------------------------------------
        Category cat;
        List<Category> categoryList = new ArrayList<>();

        List<String> catItems;


        catItems = quizInfo.getSubjects();
        if(catItems.size()>0){
            for(String item : catItems){
                cat = new Category();
                cat.setName(item);

                categoryList.add(cat);
            }
        }

        catItems = quizInfo.getTopics();
        if(catItems.size()>0){
            for(String item : catItems){
                cat = new Category();
                cat.setName(item);
                categoryList.add(cat);
            }
        }

        catItems = quizInfo.getSubtopics();
        if(catItems.size()>0){
            for(String item : catItems){
                cat = new Category();
                cat.setName(item);
                categoryList.add(cat);
            }
        }

        //-------------------------------------------------------------

        Question question;
        QuestionAnswerOption questionOption;


        List<Question> questionList = new ArrayList<>();

        for(QuizizzQuestion quest  :  quizInfo.getQuestions()){

            //Question
            String quest_id             = quest.getId();
            String quest_createdAt      = quest.getCreatedAt();
            String quest_type           = quest.getType();


            Structure quest_structure   = quest.getStructure();
            String quest_text           = quest_structure.getQuery().getText();


            OffsetDateTime createdDate  = Converters.toOffsetDateTime(quest_createdAt);
            OffsetDateTime UpdatedDate  = Instant.now().atOffset( ZoneOffset.UTC );

            // SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
            // format.setTimeZone(TimeZone.getTimeZone("UTC"));

            question = new Question();
            question.setType(quest_type);
            question.setEnabled(true);

            question.setText(quest_text);

            question.setNonce(quest_id);


            List<QuestionAnswerOption> correct = new ArrayList<>();
            List<QuestionAnswerOption> options = new ArrayList<>();
            List<Option>  quest_options  = quest_structure.getOptions();
            List<Integer> quest_answers  = quest_structure.getAnswer();

            Integer index = 0;
            for(Option opt : quest_options){
                questionOption = new QuestionAnswerOption();

                questionOption.setText(opt.getText());
                questionOption.setAnswer(false);

                if(quest_answers.contains(index)){
                    questionOption.setAnswer(true);
                    correct.add(questionOption);
                }

                options.add(questionOption);
                index++;
            }
            question.setOptions(options);
            question.setCorrectAnswers(correct);


            questionList.add(question);
        }

        //quiz.setCourseList();
        quiz.setCategoryList(categoryList);
        quiz.setQuestionList(questionList);


        return quiz;
    }
    public List<Quiz>  buildQuizToImport(Quizizz quizizz) {
        List<QuizInfo> quizInfoList = quizizz.getQuizInfoList();

        //QuizInfo quizInfo = quizizz.getQuizInfo();
        List<Quiz> qzs = new ArrayList<>();


        if (quizInfoList != null) {
            Quiz quiz = new Quiz();

            for(QuizInfo quizIfo  : quizInfoList){
                qzs.add(buildQuizToImport(quizIfo));
            }
        }
        return qzs;
    }
}


