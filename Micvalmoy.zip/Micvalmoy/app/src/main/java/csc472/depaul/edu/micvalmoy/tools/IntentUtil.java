package csc472.depaul.edu.micvalmoy.tools;

public class IntentUtil {



    public static final String EXTRA_SEARCH_PARAMETER    = "EXTRA_SEARCH_PARAMETER";
    public static final String EXTRA_QUIZINFO_ID         = "EXTRA_QUIZINFO_ID";
   
   
   
    public static final String EXTRA_QUIZ_ID             = "EXTRA_QUIZ_ID";    
    public static final String EXTRA_QUIZ_LIST_ID        = "EXTRA_QUIZ_LIST_ID";


    public static final String EXTRA_QUIZ_MODE_EXAM      = "EXTRA_QUIZ_MODE_EXAM"; 
    public static final String EXTRA_QUIZ_MODE_PRACTICE  = "EXTRA_QUIZ_MODE_PRACTICE"; 
	public static final String EXTRA_QUIZ_MODE_RESULT    = "EXTRA_QUIZ_MODE_RESULT"; 

	public static final String EXTRA_QUESTION_ID         = "EXTRA_QUESTION_ID"; 
	public static final String EXTRA_ANSWER_CHOICE_ID    = "EXTRA_ANSWER_CHOICE_ID";


    //---------------------------------------------------------------------------------
    // Parcelable objects 
	public static final String BUNDLE_KEY_QUIZ_OBJ      = "BUNDLE_KEY_QUIZ_OBJ";
	public static final String BUNDLE_KEY_CATEGORY_OBJ  = "BUNDLE_KEY_CATEGORY_OBJ";
	public static final String BUNDLE_KEY_COURSE_OBJ    = "BUNDLE_KEY_COURSE_OBJ";
	public static final String BUNDLE_KEY_QUESTION_OBJ  = "BUNDLE_KEY_QUESTION_OBJ";

}  