package csc472.depaul.edu.micvalmoy.db;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;
import android.arch.persistence.room.TypeConverters;

/**
 * bump version number if your schema changes
 *
 *  To change the schema for any tables created later, bump up the version number.
 *  The version number should always be incremented (and never downgraded) to avoid conflicts with older database versions.
 *  Making schema changes will update the definitions in the app/schemas directory
 *
 *  https://guides.codepath.com/android/Room-Guide
 *
 *  https://www.captechconsulting.com/blogs/android-architecture-components-room-persistence-library
 *  https://developer.android.com/reference/android/arch/persistence/room/Relation
 *  https://commonsware.com/AndroidArch/previews/mn-relations-in-room
 */


@Database(entities={Quiz.class, Question.class, QuestionAnswerOption.class}, version=1)

@TypeConverters({Converters.class})
public abstract class AppDatabase extends RoomDatabase {
    // Database name to be used
    public static final String DATABASE_NAME = "AppDatabase";

    public abstract QuizDao QuizDao();
    public abstract QuestionDao QuestionDao();
    public abstract QuestionAnswerOptionDao QuestionOptionDao();

}
