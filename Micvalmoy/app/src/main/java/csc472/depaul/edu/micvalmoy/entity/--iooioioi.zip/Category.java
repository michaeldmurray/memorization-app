package csc472.depaul.edu.micvalmoy.db;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

/*


 */

@Entity(tableName = "categories")
public class Category {
    @ColumnInfo
    @PrimaryKey(autoGenerate=true)
    private Long id;

    @ColumnInfo
    private String name;

    /**
     * Basic getters /setters
     */

}