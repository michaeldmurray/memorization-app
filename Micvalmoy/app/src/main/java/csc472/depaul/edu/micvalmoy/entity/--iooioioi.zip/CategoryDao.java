package csc472.depaul.edu.micvalmoy.db;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

@Dao
public interface CategoryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public long insertCategory(Category category);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<Category> categories);

    @Update
    public int updateCategory(Category category);

    @Update
    public int updateAll(Category... categories);

    @Delete
    public void deleteCategory(Category category);

    @Query("DELETE FROM categories where id=:id")
    public int deleteCategoryById(Integer id);
    //LiveData<Integer> deleteCategoryById(int id);

    @Query("DELETE FROM categories where id in (:ids)")
    public int deleteCategoryByIds(Integer... ids);

    @Query("SELECT * FROM categories WHERE id =:id")
    public LiveData<Category> fetchCategoryById(int id);


    @Query("SELECT * FROM categories WHERE id IN (:ids)")
    public LiveData<Category> fetchCategoryByIds(int ids);


    @Query("SELECT * FROM categories")
    public LiveData<List<Category>> fetchAllCategory();

    @Query("SELECT * FROM categories ORDER BY name asc")
    public LiveData<List<Category>> fetchCategoriesOrderByName();


    @Query("SELECT COUNT(*) FROM categories")
    public int getCategoryCount();
}


