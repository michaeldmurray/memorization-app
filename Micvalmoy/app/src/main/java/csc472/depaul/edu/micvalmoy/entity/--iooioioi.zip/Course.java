package csc472.depaul.edu.micvalmoy.db;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

/*

CREATE TABLE courses (
  id int(10) primary key,
  name VARCHAR(325) NOT NULL
);

*/



@Entity(tableName = "courses")
public class Course {
    @ColumnInfo
    @PrimaryKey(autoGenerate=true)
    private Long id;

    @ColumnInfo
    private String name;


    /**
     * Basic getters /setters
     */

}