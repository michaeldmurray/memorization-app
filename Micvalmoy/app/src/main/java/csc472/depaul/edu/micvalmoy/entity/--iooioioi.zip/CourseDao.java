package csc472.depaul.edu.micvalmoy.db;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

@Dao
public interface CourseDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public long insertClass(Course course);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<Course> courses);

    @Update
    public int updateClass(Course course);

    @Update
    public int updateAll(Course... course);

    @Delete
    public void deleteClass(Course course);

    @Query("DELETE FROM courses where id=:id")
    public int deleteClassById(Integer id);
    //LiveData<Integer> deleteClassById(int id);

    @Query("DELETE FROM courses where id in (:ids)")
    public int deleteClassByIds(Integer... ids);

    @Query("SELECT * FROM courses WHERE id =:id")
    public LiveData<Course> fetchClassById(int id);


    @Query("SELECT * FROM courses WHERE id IN (:ids)")
    public LiveData<Course> fetchClassByIds(int ids);


    @Query("SELECT * FROM courses")
    public LiveData<List<Course>> fetchAllClass();

    @Query("SELECT * FROM courses ORDER BY name asc")
    public LiveData<List<Course>> fetchClassesOrderByName();


    @Query("SELECT COUNT(*) FROM courses")
    public int getClassCount();
}


