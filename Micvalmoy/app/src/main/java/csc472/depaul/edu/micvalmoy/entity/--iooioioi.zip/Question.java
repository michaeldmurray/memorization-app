package csc472.depaul.edu.micvalmoy.db;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

import java.sql.Date;
import java.util.ArrayList;

/*

CREATE TABLE questions (
    id int(10) primary key,
    text varchar(1000) NOT NULL,
    hint VARCHAR(800),
    category VARCHAR(100),
    createdAt date not null,
    updatedAt date not null,
    nonce VARCHAR(100),
    type VARCHAR(10) NOT NULL  -- multiple, truefalse, termdef
);


 */


@Entity(tableName = "questions")
public class Question{
    
    @ColumnInfo
    @PrimaryKey(autoGenerate=true)
    Long id;

    @NonNull
    @ColumnInfo
    private String text;

    @ColumnInfo
    private String hint;

    @ColumnInfo
    private Date createdAt;

    @ColumnInfo
    private Date updatedAt;

    @ColumnInfo
    private String nonce;

    @NonNull
    @ColumnInfo
    private String type;



    /**
     * Basic getters /setters
     */


}
