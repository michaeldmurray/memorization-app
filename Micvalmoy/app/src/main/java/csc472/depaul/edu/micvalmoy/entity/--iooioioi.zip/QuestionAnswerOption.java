package csc472.depaul.edu.micvalmoy.db;


import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

import static android.arch.persistence.room.ForeignKey.CASCADE;


/*

CREATE TABLE question_answer_options (
    id int(10) primary key,
    question_id int(10) NOT NULL references questions(id),
    text varchar(150) NOT NULL
);

*/


@Entity(
        tableName = "question_answer_options",
        primaryKeys={"id", "question_id"},
        foreignKeys= {
                @ForeignKey(
                        entity = Question.class,
                        parentColumns = "id",
                        childColumns = "question_id",
                        onDelete = CASCADE)
        }
)
public class QuestionAnswerOption{

    @ColumnInfo
    @PrimaryKey(autoGenerate=true)
    Long id;


    @NonNull
    @ColumnInfo(name = "question_id")
    private Long questionId;

    @NonNull
    @ColumnInfo
    private String text;



    /**
     * Basic getters /setters
     */

}
