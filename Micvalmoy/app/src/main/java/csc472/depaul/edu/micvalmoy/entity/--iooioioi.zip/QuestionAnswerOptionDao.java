package csc472.depaul.edu.micvalmoy.db;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

@Dao
public interface QuestionAnswerOptionDao {


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public Long insertQuestionOption(QuestionAnswerOption questionAnswerOption);

    @Delete
    public void deleteQuestionOption(QuestionAnswerOption questionAnswerOption);

    @Update
    public int update(QuestionAnswerOption questionAnswerOption);


    @Query("SELECT * FROM question_answer_options where id = :id")
    public QuestionAnswerOption getById(int id);

    @Query("SELECT * FROM question_answer_options where question_id = :question_id")
    public QuestionAnswerOption getByQuizId(int question_id);

}

