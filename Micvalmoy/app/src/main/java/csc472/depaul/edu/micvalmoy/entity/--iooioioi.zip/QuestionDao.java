package csc472.depaul.edu.micvalmoy.db;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.PrimaryKey;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

@Dao
public interface QuestionDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public long insertQuestion(Question question);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<Question> questions);

    @Update
    public int updateQuestion(Question question);

    /**
     * Using Ellipsis to Accept Variable Number of Arguments (Var args)
     * https://www.quora.com/Why-does-3-dot-symbol-is-used-in-varargs-Java
     * Accepts a comma separated list of Question objects
     * updateAll(q1,q2)
     */
    @Update
    public int updateAll(Question... questions);

    @Delete
    public void deleteQuestion(Question question);

    @Query("DELETE FROM questions where id=:id")
    public int deleteQuestionById(Integer id);
    //LiveData<Integer> deleteQuestionById(int id);

    @Query("DELETE FROM questions where id in (:ids)")
    public int deleteQuestionByIds(Integer... ids);

    @Query("SELECT * FROM questions WHERE id =:id")
    public LiveData<Question> fetchQuestionById(int id);


    @Query("SELECT * FROM questions WHERE id IN (:ids)")
    public LiveData<Question> fetchQuestionByIds(int ids);


    @Query("SELECT * FROM questions")
    public LiveData<List<Question>> fetchAllQuestion();

    @Query("SELECT * FROM questions ORDER BY text asc")
    public LiveData<List<Question>> fetchQuestionsOrderByText();


    @Query("SELECT COUNT(*) FROM questions")
    public int getQuestionCount();
}


