package csc472.depaul.edu.micvalmoy.db;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

/*

CREATE TABLE quizzes (
  id int(10) primary key,
  name VARCHAR(325) NOT NULL,
);

 */

@Entity(tableName = "quizzes")
public class Quiz {
    @ColumnInfo
    @PrimaryKey(autoGenerate=true)
    private Long id;

    @ColumnInfo
    private String name;


    /**
     * Basic getters /setters
     */

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}