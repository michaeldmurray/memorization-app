package csc472.depaul.edu.micvalmoy.db;


import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.Index;
import android.support.annotation.NonNull;

import static android.arch.persistence.room.ForeignKey.CASCADE;

/*
-- A quiz belongs to a course


CREATE  TABLE quizz_courses (
  course_id INTEGER REFERENCES courses,
  quiz_id INTEGER REFERENCES quizzes,
  PRIMARY KEY (course_id, quiz_id)
);


 */


@Entity(
        tableName="quizz_courses",
        primaryKeys={"course_id", "quiz_id"},
        foreignKeys={
                @ForeignKey(
                        entity=Course.class,
                        parentColumns="id",
                        childColumns="course_id",
                        onDelete=CASCADE),
                @ForeignKey(
                        entity=Quiz.class,
                        parentColumns="id",
                        childColumns="quiz_id",
                        onDelete=CASCADE)},
        indices={
                @Index(value="QuizCourseCourseId"),
                @Index(value="QuizCourseQuizId")
        }
)

public class QuizCourse {
@NonNull
@ColumnInfo(name = "course_id")
public final Long courseId;

@ColumnInfo(name = "quiz_id")
@NonNull public final Long quizId;

public QuizCourse(Long courseId, Long quizId) {
        this.courseId=courseId;
        this.quizId=quizId;
        }
        }