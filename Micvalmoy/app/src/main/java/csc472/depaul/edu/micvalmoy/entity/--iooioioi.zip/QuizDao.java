package csc472.depaul.edu.micvalmoy.db;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

@Dao
public interface QuizDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public long insertQuiz(Quiz quiz);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<Quiz> quizzes);

    @Update
    public int updateQuiz(Quiz quiz);

    /**
     * Using Ellipsis to Accept Variable Number of Arguments (Var args)
     * https://www.quora.com/Why-does-3-dot-symbol-is-used-in-varargs-Java
     * Accepts a comma separated list of Quiz objects
     * updateAll(q1,q2)
     */
    @Update
    public int updateAll(Quiz... quizzes);

    @Delete
    public void deleteQuiz(Quiz quiz);

    @Query("DELETE FROM quizzes where id=:id")
    public int deleteQuizById(Integer id);
    //LiveData<Integer> deleteQuizById(int id);

    @Query("DELETE FROM quizzes where id in (:ids)")
    public int deleteQuizByIds(Integer... ids);

    @Query("SELECT * FROM quizzes WHERE id =:id")
    public LiveData<Quiz> fetchQuizById(int id);


    @Query("SELECT * FROM quizzes WHERE id IN (:ids)")
    public LiveData<Quiz> fetchQuizByIds(int ids);


    @Query("SELECT * FROM quizzes")
    public LiveData<List<Quiz>> fetchAllQuiz();

    @Query("SELECT * FROM quizzes ORDER BY name asc")
    public LiveData<List<Quiz>> fetchQuizzesOrderByName();


    @Query("SELECT COUNT(*) FROM quizzes")
    public int getQuizCount();
}
